<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
  /*   $grade=80;
        if ($grade>=75)
        echo "Passed!";
 */




 /*    $grade=74;
        if ($grade>=75)
            echo "Passed!";
        else
            echo "Failed"

 */




/*  $grade=100;
        if ($grade>=90)
            echo "Excellent!";
        elseif ($grade>=75)
            echo "Not bad!";
        else
            echo "Failed!";
 */



/* 
$x = "4";
switch ($x) {
    case 1:
        echo "Number 1";
        break;
    case 2:
        echo "Number 2";
        break;
    default:
        echo "No number between 1 and 2";
}
 */

        
    ?>
</body>
</html>
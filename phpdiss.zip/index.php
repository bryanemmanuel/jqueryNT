<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
 



<?php
// Using echo
echo "Hello World";
echo ("Hello World");

// Using print
echo "<br>";
print "Hello World";
print ("Hello World");

?>









<?php

/* $result1 = print("Hello");
echo $result1 ;
$result2 = "Helloa";
echo $result2; 
 */
?>




<?php 
/* ECHO "Hello World!<br>";
echo "Hello World!<br>";
EcHo "Hello World!<br>";
$color="red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "My boat is " . $coLOR . "<br>";  */
?>




<?php
/* $x = 10.365;
var_dump($x); // output is float(10.365)
echo "<br>";
$x = 2.4e3;
var_dump($x); // output is float(2400)
echo "<br>";
$x = 8E-5;
var_dump($x); // output is float(8.0E-5)
echo "<br>"; $x = "BSU";
var_dump($x); // output is string(3) “BSU” */
?>






</body>
</html>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sanitize</title>
</head>
<body>

<form action="">
    <input type="text" value="">
</form>
    
<?php

//HTML Entities or Character Entities



//https://www.w3schools.com/html/html_entities.asp
$Name = '<script>alert("XSS")</script>' ; 

echo htmlspecialchars($Name);



// $user_input = '<script>alert("XSS Attack!")</script>';
// echo htmlspecialchars($user_input);


?>
</body>
</html>
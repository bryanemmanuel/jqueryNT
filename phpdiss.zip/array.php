<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array</title>
</head>
<body>
    

 <?php


//Create Array
//You can create arrays by using the array() function:
//You can also use a shorter syntax by using the [] brackets:

$cars = array("Volvo","BMW", "Toyota","Honda","Ford", "Chevrolet", "Mercedes","Audi", "Nissan","Hyundai");

$cars = ["Volvo", "BMW", "Toyota", "Honda", "Ford", "Chevrolet", "Mercedes", "Audi", "Nissan", "Hyundai"];



//Multiple Lines
//Line breaks are not important, so an array declaration can span multiple lines:

$cars = array(
    "Volvo",
    "BMW",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Mercedes",
    "Audi",
    "Nissan",
    "Hyundai"
);


$cars = [
    "Volvo",
    "BMW",
    "Toyota",
    "Honda",
    "Ford",
    "Chevrolet",
    "Mercedes",
    "Audi",
    "Nissan",
    "Hyundai"
];










 //Numeric array - An array with a numeric index .
 //• A numeric array stores each array element with a numeric index. 
 //• There are two methods to create a numeric array.
 
 
 
/* //using Foreach 
 $cars=array("Juan", "Pedro", "Fernando"); 
    echo "Using for each<br>"; 

    foreach ($cars as $value){
        echo "Value: ". $value . "<br />";  
    } 

//using Loop WWW
echo "<hr>Using Loop<br>"; 

    for ( $x = 0; $x<=2; $x++){ 
        echo "Car:[$x] " . $cars[$x] . "<br />";    
}  
 */








//PHP Associative Arrays 
/* 
$ages = array(
    "Juan"    => 25,
    "Pedro"   => 30,
    "Maria"   => 22,
    "Ana"     => 28,
  
);

var_dump($ages);

echo "<br>";

echo 'Pedro age is: ' . $ages["Juan"];
echo "<br>";
echo '<hr>loop and display the keys only<hr>';

$keys = array_keys($ages);

foreach ($keys as $key) {
    echo($key) . "<br>";
}

echo '<hr>loop with it and display the value<hr>';

foreach ($ages as $key => $value) {
    echo($key) . " " . $value . "<br>";
}

 */








//PHP - Two-dimensional Arrays
//We can store the data from the table above in a two-dimensional array, like this:


  $carsD = array (array("Volvo",22,18),array("BMW",15,13),array("Saab",5,2),array("Land Rover",17,15));

  $cars = array (
         array("Volvo",22,18),
         array("BMW",15,13),
         array("Saab",5,2),
         array("Land Rover",17,15)
      );
    

echo $cars[1][0].": In stock: ".$cars[1][1].", sold: ".$cars[0][2].".<br>";
echo $cars[3][0].": In stock: ".$cars[3][1].", sold: ".$cars[3][2].".<br>";
echo $cars[3][0].": In stock: ".$cars[3][1].", sold: ".$cars[3][2].".<br>";
echo $cars[3][0].": In stock: ".$cars[3][1].", sold: ".$cars[3][2].".<br>";
;

 


  //print
/*   for ($row = 0; $row < 4; $row++) 
    {
        echo "<p><b>Row number $row</b></p>";
            
        for ($col = 0; $col < 3; $col++) {
            echo $cars[$row][$col]."<br>";
        }
            
    }
   */
 


//table
/*     echo "<table border='1' cellpadding='10'>";
        echo '<tr>
                <th>Name</th>
                <th>Stock</th>
                <th>Sold</th>
            </tr>';

        for ($row = 0; $row < 4; $row++) {
        echo "<tr>";
                for ($col = 0; $col < 3; $col++) {
                        echo "<td>".$cars[$row][$col]."</td>";
                }
        echo "</tr>";
        }
    echo "</table>"; */
 





//multidimensional array 3d
/* 
$arrayx = array(array( array(1, 2, 3),array(4, 5, 6)),array( array(7, 8, 9),array(10, 11, 12)),array( array(13, 14, 15),array(16, 17, 18)));


$array = array(
    array(
        array("lorem", 2, 3),
        array(4, 5, "gmail")
    ),
    array(
        array(7, 8, 9),
        array(10, "bry@gmail.com", 12)
    ),
    array(
        array(13, "xAP", 15),
        array(16, 17, 18)
    ),
     array(
        array(19, "20x", 21),
        array(22, 23, 24)
     ),
      array(
        array("AAA", "BBB", "CCC","DDD"),
        array(25, 26, 27)
      ),
      array(
        array("QWER", "EEE", "www",28,29,30),
        array("WWQ", "QQW", "EEQ")
    )
);
// Accessing an element (example)
echo $array[5][0][1];
echo $array[5][0][5];
 */
 ?>







</body>
</html>
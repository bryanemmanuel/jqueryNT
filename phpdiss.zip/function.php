<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php


//PHP Functions – User Defined 
    
/* function writeMsg(){ 
        echo "Hello world!";    
    } 

    writeMsg();
 */



//Function with Arguments 

/*     function familyName($fname) {
         echo "$fname <br>";
    }
         
     familyName("Naruto");
     familyName("Boruto");
     familyName("Himawari");
     familyName("Hinata");


 */



     
    
//Function with Multiple Arguments  
   
 /*    function deathNote($fname, $year) {
         echo "$fname  $year <br>";
    }
     
    deathNote("Light", "1999");
    deathNote("Ryuk", "1878");
    deathNote("Near", "2022");
         */





//PHP Default Argument Value

   /*  function setHeight($minheight = 50) {
            echo "The height is : $minheight <br>";
    }
        setHeight(350);
        setHeight(); // will use the default value of 50
        setHeight(135);
        setHeight(80); */


//PHP Functions - Returning values
    /* 
    function sum($x,$y) { 
        $z=$x+$y; 
        return $z;      
    } 
    
     echo "7 + 13 = " . sum(7,13) . "<br>"; 
     echo "2 + 4 = " . sum(2,4); 
       
          */




//Variable Number of Arguments
    
    // function sumMyNumbers(...$numbers) {
    //     $total = 0;
    //     $len = count($numbers);

    //     for($i = 0; $i < $len; $i++) {
    //         $total += $numbers[$i];
    //     }

    //     return $total;
    // }
            
    //         $sum = sumMyNumbers(5, 5, 5, 5, 5, 5);
    //         echo $sum;
    




    ?>




</body>
</html>